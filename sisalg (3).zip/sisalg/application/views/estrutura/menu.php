<nav class="menu" tabindex="0">
	<div class="smartphone-menu-trigger"></div>
  <header class="avatar">
		<img src="<?php echo base_url()?>estilos/img/user.png"  />
  <h2>Jéssica</h2>
  </header>
	<ul>
    <li class="icon-dashboard"><a href="<?php echo base_url();?>inicio"><span>Início</span></a></li>
    <li class="icon-customers"><span>Cadastro</span></li>
   	<li class="submenu"><a href="<?php echo base_url();?>cadastro/curso"><span>Curso</span></a></li>
    <li class="submenu"><a href="<?php echo base_url();?>cadastro/disciplina"><span>Disciplina</span></a></li>
   	<li class="submenu"> <a href="<?php echo base_url();?>cadastro/exercicio"><span>Exercício</span></a></li>
    <li class="submenu" ><a href="<?php echo base_url();?>cadastro/universidade"><span>Universidade</span></a></li>
    <li class="icon-settings"><span>Sistema</span></li>
    <li class="submenu"><span>Acesso</span></li>
    <li class="submenu"><span>Perfis de Acesso</span></li>
    <li class="submenu"><a href="<?php echo base_url();?>sistema/usuario"><span>Usuário</span></a></li>
    <li class="icon-users"><span>Minhas Submissões</span></li>
    <li class="icon-users"><span>Sair</span></li>
  </ul>
</nav>